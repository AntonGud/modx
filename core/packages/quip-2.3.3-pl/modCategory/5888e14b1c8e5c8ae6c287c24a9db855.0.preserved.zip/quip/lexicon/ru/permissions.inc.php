<?php
/**
 * @package quip
 * @subpackage lexicon
 */
$_lang['perm.comment_approve'] = 'Одобрять комментарий.';
$_lang['perm.comment_list'] = 'List comments for a thread.';
$_lang['perm.comment_list_unapproved'] = 'List unapproved comments.';
$_lang['perm.comment_remove'] = 'Удалять комментарии.';
$_lang['perm.comment_update'] = 'Редактировать комментарии.';
$_lang['perm.thread_list'] = 'List available threads.';
$_lang['perm.thread_manage'] = 'Управлять темами.';
$_lang['perm.thread_truncate'] = 'Удалить все комментарии в теме.';
$_lang['perm.thread_update'] = 'Редактировать тему.';
$_lang['perm.thread_view'] = 'Просмотр темы.';
